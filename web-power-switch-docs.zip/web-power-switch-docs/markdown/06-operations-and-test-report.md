# Operations and test report

**Document type:** Lab qualification / acceptance checklist  
**Last updated:** 3 July 2026  
**Tester:** Navjyot Mandale

## 1. Scope

Acceptance criteria and test procedure for the BBB Web Power Switch.

## 2. System under test

| ID | Relays | Result |
| --- | --- | --- |
| BBB-U1 | 2 | PASS — deployed and verified |
| BBB-U2 | 4 | PASS — deployed and verified |

Web login uses the username and password in each board's `config.yaml`.

## 3. Acceptance criteria

| # | Requirement | Pass criteria |
| --- | --- | --- |
| AC-1 | Web UI accessible | Login page loads at :8080 |
| AC-2 | Authentication | Valid credentials grant access; invalid credentials are rejected |
| AC-3 | Relay ON/OFF | Each relay toggles; audible click and LED on the relay board |
| AC-4 | GPIO readback | Refresh Status shows the correct ON/OFF per relay |
| AC-5 | Power cycle | 30s OFF then ON completes; timer visible in the UI |
| AC-6 | All OFF | Master control turns all relays OFF |
| AC-7 | Auto-start | Service is running after reboot |
| AC-8 | Persistence | Server stays up after the SSH session closes |
| AC-9 | Live notes | Relay notes save and persist |
| AC-10 | Independent units | Each BBB works without a central lab PC |

## 4. Test procedure

### Pre-test

- [ ] Board powered and on the network
- [ ] Relay module wired (P9 pin 1 GND, pin 7 +5V)
- [ ] DUT power routed through relay COM to NO
- [ ] `sudo systemctl status bbb-relay-local` shows **active (running)**

### Functional tests (3 July 2026)

| Step | Action | Expected result | BBB-U1 | BBB-U2 |
| --- | --- | --- | --- | --- |
| T1 | Open Web UI :8080 | Login page displayed | PASS | PASS |
| T2 | Login | Relay table shown | PASS | PASS |
| T3 | Switch ON (Relay 1) | Relay clicks ON, state green | PASS | PASS |
| T4 | Switch OFF (Relay 1) | Relay stays OFF (no snap-back) | PASS | PASS |
| T5 | Cycle (Relay 1) | 30s countdown, then ON | PASS | PASS |
| T6 | Refresh Status | GPIO state matches hardware | PASS | PASS |
| T7 | All outlets OFF | All relays OFF | PASS | PASS |
| T8 | All 4 relays ON/OFF | Each channel responds | N/A | PASS |
| T9 | `/api/health` | `{"ok": true}` | PASS | PASS |

```bash
curl http://<bbb-ip>:8080/api/health
# {"ok":true,"mode":"local","bbbs":1}
```

## 5. Issues found and resolved (3 July 2026)

| Issue | Root cause | Fix |
| --- | --- | --- |
| Relay OFF snaps back ON after ~1s | `status` re-ran `config-pin` and rewrote GPIO direction, resetting the active-low output to ON | Read-only `status`; `relay_prepare_output` sets direction only when needed |
| GUI buttons return HTTP 500 | GPIO stuck as `direction=in` (`Operation not permitted`) | Redeploy the fixed relay script so direction is `out` before write |
| 4-channel unit not responding | Old script on the unit during the first deploy | Deployed fixed `relay_control_4ch.sh`; all 4 channels verified |

## 6. Known limitations

1. **No HTTPS** — HTTP only on port 8080 (lab network)
2. **Single user** — one admin account in the yaml
3. **No server audit log** — actions show in the browser System Log
4. **Cycle timing** — the 30s delay is driven by the client plus the script

## 7. Follow-up

- [x] Both units deployed and GPIO fix applied
- [x] Backup package of the working files
- [ ] Wire DUT DC+ through every relay channel on the bench
- [ ] HTTPS if the UI is ever reachable outside the lab VLAN
- [ ] Multi-user authentication
