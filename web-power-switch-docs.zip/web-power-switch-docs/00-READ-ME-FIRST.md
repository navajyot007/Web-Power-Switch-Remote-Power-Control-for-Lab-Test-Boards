# Web Power Switch — document pack

Use the resume file first. The other files are the full notes, in order.

## For your resume (short)

- `resume/Web-Power-Switch-Resume.md`
- `resume/Web-Power-Switch-Resume.pdf`

## Full notes (same text in Markdown and PDF)

| Order | What it is | Markdown | PDF |
| --- | --- | --- | --- |
| 1 | Project overview | `markdown/01-README.md` | `pdf/01-README.pdf` |
| 2 | Documentation hub | `markdown/02-documentation-hub.md` | `pdf/02-documentation-hub.pdf` |
| 3 | How it works (flow) | `markdown/03-architecture-and-flow.md` | `pdf/03-architecture-and-flow.pdf` |
| 4 | Wiring | `markdown/04-hardware-wiring.md` | `pdf/04-hardware-wiring.pdf` |
| 5 | How to install | `markdown/05-software-deployment.md` | `pdf/05-software-deployment.pdf` |
| 6 | Test results | `markdown/06-operations-and-test-report.md` | `pdf/06-operations-and-test-report.pdf` |
| 7 | How to fix problems | `markdown/07-troubleshooting.md` | `pdf/07-troubleshooting.pdf` |
| 8 | List of code files | `markdown/08-project-file-list.md` | `pdf/08-project-file-list.pdf` |
