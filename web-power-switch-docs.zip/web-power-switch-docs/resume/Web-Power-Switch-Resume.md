# Web Power Switch

**Remote power control for lab test boards**  
Python, Flask, BeagleBone Black, GPIO, Linux systemd

Built a small web tool so engineers can turn lab board power on and off from a browser. Each BeagleBone runs its own server. No extra PC is needed after setup. The tool stays on after reboot.

- Browser page to switch each relay ON, OFF, or run a 30-second power cycle
- Works on a 2-relay board and a 4-relay board
- Saves the last ON/OFF state and puts it back after power loss
- Shows a clear warning when the board is offline
- Fixed a bug where a relay turned itself back ON
- Installed on two lab units and checked every channel
- Wrote short guides for wiring, setup, testing, and fixes

**One line for a resume**

Built a browser-based power switch on BeagleBone Black so lab engineers can remotely turn test-board power on, off, and cycle it, with auto-start after reboot.
