# BBB Web Power Switch — Documentation Hub

**Author:** Navjyot Mandale  
**Last updated:** 3 July 2026  
**Status:** Production — both units verified working

## Purpose

Browser-based **Web Power Switch** for lab benches. Each **BeagleBone Black (BBB)** runs its own web server and controls relay modules for DUT power cycling.

Each BBB is an **independent appliance**. No central lab PC is required after deployment.

## Quick reference

| Unit | Relays | Web UI | Status |
| --- | --- | --- | --- |
| BBB Unit 1 | 2 | `http://<bbb1-ip>:8080` | LIVE |
| BBB Unit 2 | 4 | `http://<bbb2-ip>:8080` | LIVE |

**Login (both units):** `admin` / `change-me` (set your own password in `config.bbb1.yaml` and `config.bbb2.yaml`)

**Health check:**

```bash
curl http://<bbb-ip>:8080/api/health
```

## Pages in this folder

| File | Contents |
| --- | --- |
| [01-architecture-and-flow.md](01-architecture-and-flow.md) | System design, data flow, software stack |
| [02-hardware-wiring.md](02-hardware-wiring.md) | P9 pin map, relay connections, power |
| [03-software-deployment.md](03-software-deployment.md) | Copy, install, systemd |
| [04-operations-and-test-report.md](04-operations-and-test-report.md) | Acceptance criteria and test results |
| [05-troubleshooting.md](05-troubleshooting.md) | Health checks, GPIO fixes, recovery |

## High-level architecture

```
  Engineer Browser (any PC on the lab network)
           |
           | HTTP :8080
           v
  +---------------------------+
  | BeagleBone Black (BBB)    |
  |  Flask + Gunicorn         |
  +------------+--------------+
               | sudo (local)
               v
  +---------------------------+
  | relay_control*.sh         |
  | sysfs GPIO (active-low)   |
  +------------+--------------+
               | IN1..IN4
               v
  +---------------------------+
  | 2-ch or 4-ch Relay Module |
  | COM -> NO -> DUT DC+      |
  +---------------------------+
```

## Software packages in this download

| Path | Description |
| --- | --- |
| repository root | Active per-BBB server (production design) |
| `gpio/` | Relay control scripts |
| `legacy/` | Central-hub server (deprecated) |
