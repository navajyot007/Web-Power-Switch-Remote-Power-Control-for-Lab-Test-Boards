# Web Power Switch

Browser-based remote power control for lab benches. Each BeagleBone Black runs its own Flask + Gunicorn server and switches a relay module over GPIO. After install, no central lab PC is required.

**Author:** Navjyot Mandale  
**Status:** Production (July 2026) — 2-channel and 4-channel units verified

## What it does

- Login-protected web UI on port **8080**
- Per-relay **ON / OFF** and a **30 second power cycle**
- Live GPIO readback (active-low: `0` = ON, `1` = OFF)
- Offline banner when the board drops off the network
- Relay state saved and restored after reboot (`systemd`)

## Architecture flow

```
Engineer browser
        |  HTTP :8080
        v
BeagleBone Black
  Gunicorn + Flask (server.py)
  systemd: bbb-relay-local
        |  sudo relay script
        v
sysfs GPIO (active-low)
        v
2-ch or 4-ch relay module (SONGLE SRD-05VDC)
        |  COM -> NO (DC+ only)
        v
DUT power input
```

```mermaid
flowchart TD
    browser[Browser] -->|HTTP 8080| gunicorn[Gunicorn]
    gunicorn --> flask[Flask server.py]
    flask --> controller[LocalRelayController]
    flask --> notes[notes_store.py]
    flask --> state[relay_state_store.py]
    controller --> script[relay_control.sh or relay_control_4ch.sh]
    script --> gpio[sysfs GPIO]
    gpio --> relay[Relay module]
    relay --> dut[DUT DC+]
```

**v1** (folder `legacy/`) was a central lab PC that SSHed into each board. **v2** (this folder) runs on the board itself.

## Hardware

| P9 pin | Signal | Connect to |
| --- | --- | --- |
| 1 | GND | Relay GND |
| 7 | +5V SYS | Relay VCC |
| 12 | GPIO 60 | Relay IN1 |
| 11 | GPIO 30 | Relay IN2 |
| 13 | GPIO 31 | Relay IN3 (4-channel only) |
| 14 | GPIO 50 | Relay IN4 (4-channel only) |

## Project files

| Path | Role |
| --- | --- |
| `server.py` | Flask API and session login |
| `relay_controller_local.py` | Calls the relay script with sudo |
| `notes_store.py` | Live-edited relay notes |
| `relay_state_store.py` | Saves ON/OFF so reboot can restore it |
| `restore_relay_state.py` / `restore-relay-state.sh` | Restore state before the web server starts |
| `bbb_util.py` | Small shared helpers |
| `templates/index.html` | Web UI |
| `config.bbb1.yaml` | 2-relay profile |
| `config.bbb2.yaml` | 4-relay profile |
| `run-gunicorn.sh` / `start.sh` | Process start |
| `install-on-bbb.sh` | venv, sudoers, systemd on the board |
| `deploy-to-bbbs.sh` | Copy this tree to both boards |
| `bbb-relay-local.service` | Boot service |
| `gpio/relay_control.sh` | 2-channel GPIO script |
| `gpio/relay_control_4ch.sh` | 4-channel GPIO script |
| `gpio/relay_control.py` | Earlier Python GPIO helper |
| `legacy/` | Deprecated central-hub server |
| `requirements.txt` | Flask, PyYAML, Gunicorn |
| `docs/` | Hub, flow, wiring, deploy, test report, troubleshooting |

## Documents

1. [Documentation hub](docs/00-documentation-hub.md)
2. [Architecture and flow](docs/01-architecture-and-flow.md)
3. [Hardware wiring](docs/02-hardware-wiring.md)
4. [Software deployment](docs/03-software-deployment.md)
5. [Operations and test report](docs/04-operations-and-test-report.md)
6. [Troubleshooting and health checks](docs/05-troubleshooting.md)

## Run locally (UI only)

GPIO scripts need a BeagleBone. On a normal PC the UI and API still start if you point config at the scripts and accept relay commands failing.

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export FLASK_SECRET="replace-with-a-long-random-string"
# copy a profile to the name the installer expects, or edit host/script paths
cp config.bbb1.yaml config.yaml
./start.sh
```

Open `http://127.0.0.1:8080`. Login user is `admin`. Set your own password in the yaml before use. This package ships with `change-me`.

## Deploy on a BeagleBone

```bash
# on the board, after copying this folder to ~/bbb_relay_web
# and the matching script to ~/bbb_relay_test/
sudo ./install-on-bbb.sh bbb1    # 2 relays
sudo ./install-on-bbb.sh bbb2    # 4 relays
sudo systemctl status bbb-relay-local
curl http://127.0.0.1:8080/api/health
```

Health response: `{"ok": true, "mode": "local", "bbbs": 1}`

## Before you publish this repository

- Password in this copy is already `change-me`. Do not commit a real password.
- Lab IP addresses in the yaml and docs are from an internal bench network. Replace them if the repository is public.
- Set `FLASK_SECRET` in the environment. The fallback in `server.py` is only a placeholder.
