# Architecture and flow

**Last updated:** 3 July 2026

## 1. System context

The Web Power Switch replaces a commercial networked PDU with a BeagleBone Black plus a relay module.

### Design goals

1. **Remote power cycle** of lab DUT boards from any browser on the lab network
2. **Per-BBB independence** — each unit is self-contained
3. **Always-on** — systemd survives reboot and SSH logout
4. **Live status** — GPIO readback shows the true relay ON/OFF state

## 2. Block diagram

```
+------------------------------------------------------------------+
|                         LAB NETWORK                              |
|   +----------------+              +----------------+             |
|   | Browser        |              | Browser        |             |
|   +-------+--------+              +-------+--------+             |
|           | HTTP :8080                    | HTTP :8080           |
|           v                                 v                    |
|   +-------------------+           +-------------------+          |
|   | BBB Unit 1        |           | BBB Unit 2        |          |
|   | 2 relays          |           | 4 relays          |          |
|   +---------+---------+           +---------+---------+          |
|             v                               v                    |
|   +-------------------+           +-------------------+          |
|   | Relay Module 2ch  |           | Relay Module 4ch  |          |
|   +---------+---------+           +---------+---------+          |
|             v                               v                    |
|        [ DUT Board ]                  [ DUT Board(s) ]           |
+------------------------------------------------------------------+
```

## 3. Software architecture

```
Browser (HTML/JS)
    |  POST /api/relay, GET /api/bbbs, GET /api/health
    v
Gunicorn :8080
    v
Flask server.py
    |-- LocalRelayController --> sudo gpio/relay_control*.sh
    |-- notes_store.py (live notes)
    |-- relay_state_store.py (saved ON/OFF)
    v
sysfs GPIO (/sys/class/gpio)  [active-low: 0=ON, 1=OFF]
    v
Relay Module --> DUT power
```

```mermaid
sequenceDiagram
    participant User
    participant UI
    participant Flask
    participant Script
    participant GPIO
    User->>UI: Click Cycle
    UI->>Flask: POST /api/relay action=off
    Flask->>Script: sudo relay_control*.sh offN
    Script->>GPIO: write 1
    UI->>UI: 30 second countdown
    UI->>Flask: POST /api/relay action=on
    Flask->>Script: sudo relay_control*.sh onN
    Script->>GPIO: write 0
    UI->>Flask: GET /api/bbbs
    Flask->>Script: status (read only)
    Script-->>Flask: gpio values
    Flask-->>UI: ON/OFF
```

## 4. Data flow — 30 second power cycle

1. User clicks **Cycle** in the browser
2. `POST /api/relay {action: off, channel: N}` turns the relay OFF
3. The UI counts down 30 seconds (client-side timer)
4. `POST /api/relay {action: on, channel: N}` turns the relay ON
5. `GET /api/bbbs` syncs read-only GPIO status

GPIO `status` is **read-only**. It does not reconfigure pins. That stops the relay from snapping back ON after OFF.

## 5. Boot restore flow

1. User changes a relay from the UI
2. `relay_state_store.py` writes `saved_relay_state.json`
3. On the next boot, systemd `ExecStartPre` runs `restore-relay-state.sh`
4. The script drives each channel back to the saved ON or OFF state
5. Gunicorn then starts the web server

## 6. Evolution: central hub to per-BBB local

| Generation | Host | Control path | Status |
| --- | --- | --- | --- |
| v1 | lab PC (SSH hub) | Browser → lab PC → SSH → BBB | Deprecated (`legacy/`) |
| v2 (current) | Each BBB locally | Browser → BBB:8080 → local GPIO | Production |

## 7. Technology stack

| Layer | Technology | Role |
| --- | --- | --- |
| Frontend | HTML, CSS, JavaScript | Login, relay table, 30s cycle timer |
| Web server | Gunicorn + Flask 3.x | REST API, session auth |
| Config | YAML + JSON | Static config and live-edited notes |
| GPIO control | Bash + sysfs | direction set only when needed; read-only status |
| Process manager | systemd | `bbb-relay-local.service` |
| OS | Ubuntu 22.04 on BBB | ARM Linux |

## 8. GPIO relay script design

| Function | Behaviour |
| --- | --- |
| `relay_prepare_output` | Export and config-pin on first use; set direction to `out` only if it is not already output |
| `relay_set` | Write GPIO value (`0` = ON, `1` = OFF) without rewriting direction every time |
| `status` | Read-only GPIO read — no config-pin, no direction rewrite |

This fixes the bug where Switch OFF was reversed about 1 second later by a status refresh.
