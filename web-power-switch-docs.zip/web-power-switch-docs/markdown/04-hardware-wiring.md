# Hardware wiring guide

**Last updated:** 3 July 2026

## Power supply (both units)

| P9 pin | Signal | Connect to |
| --- | --- | --- |
| **1** | GND | Relay module **GND** |
| **7** | +5V (SYS) | Relay module **VCC** |

Use **pin 7** for relay coil power. Pin 5 has no voltage on USB-only power.

## BBB Unit 1 — 2 relays — verified

| Relay | P9 pin | GPIO | Relay input |
| --- | --- | --- | --- |
| Relay 1 | 12 | 60 | IN1 |
| Relay 2 | 11 | 30 | IN2 |

**Relay type:** SONGLE SRD-05VDC — **active-low** (GPIO LOW = relay ON)

```
BeagleBone P9          Relay Module (2-ch)
Pin 1  (GND)    ---->  GND
Pin 7  (+5V)    ---->  VCC
Pin 12 (GPIO60) ---->  IN1
Pin 11 (GPIO30) ---->  IN2

DUT: DC+ -> Relay COM -> NO -> DUT DC+
     DC- direct to DUT (not through the relay)
```

## BBB Unit 2 — 4 relays — verified

| Relay | P9 pin | GPIO | Relay input |
| --- | --- | --- | --- |
| Relay 1 | 12 | 60 | IN1 |
| Relay 2 | 11 | 30 | IN2 |
| Relay 3 | 13 | 31 | IN3 |
| Relay 4 | 14 | 50 | IN4 |

Same power: **P9 pin 1 (GND)**, **P9 pin 7 (+5V)**.

Avoid P9 pin 10. That pin is SYS_RESETN, not a GPIO you should drive.

## GPIO logic (active-low)

| sysfs value | Relay state | DUT power |
| --- | --- | --- |
| `0` | ON (energized) | Powered |
| `1` | OFF (de-energized) | Unpowered |

## Verification commands

```bash
# 2-channel
sudo ~/bbb_relay_test/relay_control.sh status
sudo ~/bbb_relay_test/relay_control.sh test

# 4-channel
sudo ~/bbb_relay_test/relay_control_4ch.sh status
sudo ~/bbb_relay_test/relay_control_4ch.sh pins
sudo ~/bbb_relay_test/relay_control_4ch.sh test

# Direction must be "out"
cat /sys/class/gpio/gpio60/direction
```

## Safety

1. Wire **DC+ only** through relay COM to NO
2. Default safe state: all relays OFF (`alloff`)
3. Relay coil is 5V — use P9 pin 7
4. Label each channel in the web UI so the bench stays identifiable
