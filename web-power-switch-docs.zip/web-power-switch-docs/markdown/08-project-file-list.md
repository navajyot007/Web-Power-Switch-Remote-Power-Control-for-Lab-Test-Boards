# Project file list

**Author:** Navjyot Mandale  
**Project:** Web Power Switch (ELI-1460)

Every file that makes the per-BBB web power switch run, plus the deprecated central-hub copy.

## 1. Web server (runs on each BeagleBone)

| File | Purpose |
| --- | --- |
| `server.py` | Flask app: login, relay API, health check |
| `relay_controller_local.py` | Runs the GPIO script with sudo |
| `notes_store.py` | Saves relay notes edited in the UI |
| `relay_state_store.py` | Saves ON/OFF so a reboot can restore it |
| `restore_relay_state.py` | Applies the saved state at boot |
| `restore-relay-state.sh` | systemd pre-start wrapper for the restore |
| `bbb_util.py` | Shared helpers |
| `templates/index.html` | Login page and relay table |
| `requirements.txt` | Flask, PyYAML, Gunicorn |
| `config.bbb1.yaml` | 2-relay board profile |
| `config.bbb2.yaml` | 4-relay board profile |
| `run-gunicorn.sh` | Starts Gunicorn on port 8080 |
| `start.sh` | Local start helper |
| `install-on-bbb.sh` | venv, sudoers, and systemd install |
| `deploy-to-bbbs.sh` | Copies the app to both boards |
| `bbb-relay-local.service` | Boot service unit |

## 2. GPIO scripts

| File | Purpose |
| --- | --- |
| `gpio/relay_control.sh` | 2-channel relay (GPIO 60 and 30) |
| `gpio/relay_control_4ch.sh` | 4-channel relay (GPIO 60, 30, 31, 50) |
| `gpio/relay_control.py` | Earlier Python GPIO helper |

## 3. Documents in this package

| # | Markdown | PDF |
| --- | --- | --- |
| 1 | `01-README.md` | `01-README.pdf` |
| 2 | `02-documentation-hub.md` | `02-documentation-hub.pdf` |
| 3 | `03-architecture-and-flow.md` | `03-architecture-and-flow.pdf` |
| 4 | `04-hardware-wiring.md` | `04-hardware-wiring.pdf` |
| 5 | `05-software-deployment.md` | `05-software-deployment.pdf` |
| 6 | `06-operations-and-test-report.md` | `06-operations-and-test-report.pdf` |
| 7 | `07-troubleshooting.md` | `07-troubleshooting.pdf` |
| 8 | `08-project-file-list.md` | `08-project-file-list.pdf` |

## 4. Legacy central hub (deprecated)

Kept in `legacy/` for history. Production uses the local server above.

| File | Purpose |
| --- | --- |
| `legacy/server.py` | Old hub that reached boards over SSH |
| `legacy/relay_controller.py` | SSH relay calls |
| `legacy/add_bbb.py` | Add a board to the hub config |
| `legacy/setup-bbb-ssh.sh` | SSH key setup |
| `legacy/install-service.sh` | Hub service install |
| `legacy/bbb-relay-web.service` | Hub systemd unit |
| `legacy/config.yaml` | Hub config |
| `legacy/config.example.yaml` | Hub config template |
| `legacy/sudoers.bbb-relay` | Sudoers snippet |
| `legacy/templates/index.html` | Older UI |
