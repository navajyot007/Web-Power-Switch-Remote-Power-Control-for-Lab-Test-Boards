# Troubleshooting and health checks

**Last updated:** July 2026

Use this when the BeagleBone answers on the network but the Web Power Switch GUI does not work, relays do not move, or status looks wrong.

## Units

| Unit | Relays | Relay script on the board |
| --- | --- | --- |
| BBB Unit 1 | 2 | `~/bbb_relay_test/relay_control.sh` |
| BBB Unit 2 | 4 | `~/bbb_relay_test/relay_control_4ch.sh` |

Web UI: `http://<bbb-ip>:8080`  
Login: username and password from that board's `config.yaml`.

## Quick health check

### 1. Can you reach the board?

```bash
ping -c 3 <bbb-ip>
```

If ping fails, check power, Ethernet, and the bench VLAN.

### 2. Is the web server running?

```bash
curl http://<bbb-ip>:8080/api/health
```

Expected:

```json
{"ok": true, "mode": "local", "bbbs": 1}
```

| Result | Meaning |
| --- | --- |
| JSON with `"ok": true` | Web server is up |
| Connection refused or timeout | Service is down or port 8080 is blocked |
| Page loads but buttons fail | Server is up; relay or GPIO is the problem |

### 3. Login and status

1. Open the Web UI and log in
2. Click **Refresh Status**
3. Relays should show **ON** or **OFF** and the unit should show **online**

If refresh fails, open **System Log** in the sidebar and read the error.

## SSH checks

```bash
ssh ubuntu@<bbb-ip>
sudo systemctl status bbb-relay-local
ss -tlnp | grep 8080
curl http://127.0.0.1:8080/api/health
journalctl -u bbb-relay-local -n 50 --no-pager
```

`POST /api/relay` with HTTP 500 means the web server is up and the **relay script failed**.

## Relay script tests (bypass the GUI)

**2 relays:**

```bash
sudo ~/bbb_relay_test/relay_control.sh status
sudo ~/bbb_relay_test/relay_control.sh on1
sudo ~/bbb_relay_test/relay_control.sh off1
```

**4 relays:** same pattern with `relay_control_4ch.sh` and `on1`–`on4` / `off1`–`off4`.

| GPIO value | Relay state |
| --- | --- |
| `0` | ON |
| `1` | OFF |

Example: `relay1=0 relay2=1` means Relay 1 ON and Relay 2 OFF.

## GPIO direction

`Operation not permitted` usually means the pin is stuck as **input**.

```bash
cat /sys/class/gpio/gpio60/direction   # Relay 1 — expect out
cat /sys/class/gpio/gpio30/direction   # Relay 2 — expect out
# 4-channel also uses gpio31 and gpio50
```

Temporary fix until you redeploy:

```bash
sudo bash -c 'echo out > /sys/class/gpio/gpio60/direction'
```

## Common problems

| Symptom | Likely cause | What to do |
| --- | --- | --- |
| Browser cannot open `:8080` | Web service down | `sudo systemctl restart bbb-relay-local` |
| Health check OK, buttons do nothing | Relay script error (HTTP 500) | `journalctl -u bbb-relay-local`, then test the script over SSH |
| `Operation not permitted` | GPIO direction is `in` | Redeploy the relay script |
| OFF, then ON again after ~1 sec | Old script reconfigures GPIO on status | Redeploy the latest `relay_control*.sh` |
| Unit shows **offline** in the GUI | Relay script file missing | Confirm `~/bbb_relay_test/relay_control*.sh` exists |
| Works until reboot, then stops | Service not enabled | `sudo systemctl enable bbb-relay-local` |

## Troubleshooting flow

```
Start: GUI not working
        |
        v
   Ping BBB IP? ----NO----> Check power / network / IP
        |
       YES
        v
   curl /api/health OK? ----NO----> systemctl status bbb-relay-local
        |                              restart service, read logs
       YES
        v
   Login + Refresh OK? ----NO----> Check credentials / session / logs
        |
       YES
        v
   Switch ON/OFF works? ----NO----> Test relay_control*.sh over SSH
        |                              check GPIO direction and HTTP 500 logs
       YES
        v
      Done
```

## Files on each board

| Path | Purpose |
| --- | --- |
| `~/bbb_relay_web/` | Flask server, templates, config |
| `~/bbb_relay_test/relay_control.sh` | 2-channel script |
| `~/bbb_relay_test/relay_control_4ch.sh` | 4-channel script |
| `/etc/systemd/system/bbb-relay-local.service` | systemd unit |
| `/etc/sudoers.d/bbb-relay` | Passwordless sudo for the relay scripts |
