# Software deployment guide

**Last updated:** 3 July 2026

## Prerequisites

| Item | Requirement |
| --- | --- |
| Dev PC | SSH access to the BeagleBones |
| BBB OS | Ubuntu 22.04 (rcn-ee image) |
| BBB user | `ubuntu` |
| Network | Boards reachable from the bench VLAN |
| Python | 3.10+ on the board |

Login for the web UI is `admin` and the password in `config.bbb1.yaml` / `config.bbb2.yaml`. This download uses `change-me`. Set a real password before you deploy.

## Profiles

| Unit | Profile | Relay script |
| --- | --- | --- |
| BBB Unit 1 | `bbb1` (2 ch) | `gpio/relay_control.sh` |
| BBB Unit 2 | `bbb2` (4 ch) | `gpio/relay_control_4ch.sh` |

Web UI: `http://<bbb-ip>:8080`

## One-command deploy (both boards)

From the machine that can SSH to both boards, edit the IP list inside `deploy-to-bbbs.sh`, then:

```bash
./deploy-to-bbbs.sh
```

## Deploy one new board

```bash
# 2 relays
./deploy-to-bbbs.sh
# or on the board after you copy the files:
cd ~/bbb_relay_web && sudo ./install-on-bbb.sh bbb1

# 4 relays
cd ~/bbb_relay_web && sudo ./install-on-bbb.sh bbb2
```

Manual copy outline:

```bash
HOST=<bbb-ip>
ssh ubuntu@${HOST} 'mkdir -p ~/bbb_relay_web ~/bbb_relay_test'

scp server.py relay_controller_local.py bbb_util.py notes_store.py \
    relay_state_store.py restore_relay_state.py requirements.txt \
    config.bbb1.yaml config.bbb2.yaml run-gunicorn.sh start.sh \
    install-on-bbb.sh bbb-relay-local.service restore-relay-state.sh \
    ubuntu@${HOST}:~/bbb_relay_web/

scp -r templates ubuntu@${HOST}:~/bbb_relay_web/
scp gpio/relay_control.sh gpio/relay_control_4ch.sh ubuntu@${HOST}:~/bbb_relay_test/

ssh -t ubuntu@${HOST} 'chmod +x ~/bbb_relay_web/*.sh ~/bbb_relay_test/*.sh && cd ~/bbb_relay_web && sudo ./install-on-bbb.sh bbb1'
```

Use `bbb2` and `relay_control_4ch.sh` for the 4-channel unit.

## First-time SSH key

```bash
ssh-copy-id ubuntu@<bbb-ip>
```

## systemd

```bash
sudo systemctl status bbb-relay-local
sudo systemctl restart bbb-relay-local
sudo systemctl enable bbb-relay-local
journalctl -u bbb-relay-local -f
```

## File layout on each board

```
/home/ubuntu/
├── bbb_relay_web/
│   ├── server.py
│   ├── relay_controller_local.py
│   ├── config.yaml          # copied from config.bbb1.yaml or config.bbb2.yaml
│   ├── templates/index.html
│   ├── live_notes.json
│   └── saved_relay_state.json
└── bbb_relay_test/
    ├── relay_control.sh       # 2-channel
    └── relay_control_4ch.sh   # 4-channel
```

## Relay script rules

- `relay_prepare_output` sets GPIO direction only when needed (avoids a reset glitch)
- `status` is read-only and does not re-run `config-pin` (fixes the OFF snap-back bug)

Always deploy the scripts from `gpio/` in this repository.

## If something fails

See [05-troubleshooting.md](05-troubleshooting.md).

| Symptom | Fix |
| --- | --- |
| Page will not load | `sudo systemctl restart bbb-relay-local` |
| HTTP 500 on a relay click | Redeploy the relay script and check GPIO direction |
| OFF snaps back ON | Redeploy the latest `relay_control*.sh` |
| SSH timeout | Confirm the IP with ping |
